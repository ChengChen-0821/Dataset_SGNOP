%stkInit;
%remMachine = stkDefaultHost;
%conid = stkOpen(remMachine);

% addpath('C:\ProgramData\AGI\STK MATLAB')
% startup
% stkInit

objNames = stkObjNames;
%disp(stkObjNames)
dt = 60;
style = 'Access';
startTime = 0;
endTime = 86400*7;

 [secData, secNames] =stkAccReport(char(objNames(int32(111))),char(objNames(int32(2))),style,startTime,endTime,dt);
%%
% 
%  PREFORMATTED
%  TEXT
% 
ground ={};
for i = 1:100
    ground{i} = num2str(i);
end
ground = {'Aomen-1','Aomen-2','Atux-1','Atux-2','Axi-1','Axi-2','Baisha-1','Baisha-2','Bar-1','Bar-2','Bayan-1','Bayan-2','Beijing-1','Beijing-2','Bole-1','Bole-2','Changchun-1','Changchun-2','Changji-1','Changji-2','Changshan-1','Changshan-2','Chengdu-1','Chengdu-2','Chongqing-1','Chongqing-2','Dengta-1','Dengta-2','Fuzhou-1','Fuzhou-2','Guiyang-1','Guiyang-2','Haikou-1','Haikou-2','Harbin-1','Harbin-2','Hefei-1','Hefei-2','Hor-1','Hor-2','Jiamusi-1','Jiamusi-2','Jiazha-1','Jiazha-2','Jinan-1','Jinan-2','Jiuquan-1','Jiuquan-2','Karakax-1','Karakax-2','Korgan-1','Korgan-2','Kunming-1','Kunming-2','Lanzhou-1','Lanzhou-2','Lasa-1','Lasa-2','Manzhouli-1','Manzhouli-2','Nanchang-1','Nanchang-2','Nanning-1','Nanning-2','Qiaotou-1','Qiaotou-2','Raka-1','Raka-2','Rongme-1','Rongme-2','Shanghai-1','Shanghai-2','Shangzhou-1','Shangzhou-2','Shenyang-1','Shenyang-2','Shenzhen-1','Shenzhen-2','Taiwan-1','Taiwan-2','Taiyuan-1','Taiyuan-2','Wuhan-1','Wuhan-2','Xian-1','Xian-2','Xichang-1','Xichang-2','Xining-1','Xining-2','Yen-1','Yen-2','Yinchuan-1','Yinchuan-2','Yuli-1','Yuli-2','Yushu-1','Yushu-2','Zhengzhou-1','Zhengzhou-2'};
kd = {'��','��'};
bs =  {['����վ��ʶ,','���Ǳ�ʶ,','��ʼ����ʱ��,','��������ʱ��,','��ʼ����ʱ��,','��������ʱ��,','�Ƿ�����,','�������,','����ִ������,','Ȧ��,','�������ʶ']};
TemData_i = {}; %���ڱ������пɼ�����
for i = 102:1101    
    disp(i)
    TemData_j={};
    for j = 2:101
            if i ~= j
                    %disp(j)
                    
                    [secData, secNames] =stkAccReport(char(objNames(int32(i))),char(objNames(int32(j))),style,startTime,endTime,dt);
                    [temp1,temp2] = size(secData{1});
                    if temp2 == 4
                            [a,b,c,d] = secData{1}.data;
                            % a: Access b:Start Time c:End Time d:Duration
                            for k = 1: size(a)
                                    % �жγ���ʱ���Ƿ����100s
                                    if d(k) >= 100
                                        b1 = floor(b(k));
                                        c1 = ceil(c(k));
%                                         if c1<86400
%                                             rq=1;
%                                         else
%                                             rq=2;
%                                         end
                                        rq = ceil(c1/86400);
                                        TemData_j(end+1) = {[ground(j-1),strcat('����-',num2str(i-101)),b1,c1,b1-20,c1+20,kd(randi(2)),'*',rq,'*','*']};
                                    end
                            end
                    end
            end
    end
    TemData_i(i-101) = {TemData_j};
end


stkClose(conid);
stkClose;
