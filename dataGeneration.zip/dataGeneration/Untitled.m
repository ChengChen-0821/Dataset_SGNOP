data = load('ttm.mat');
writetable(struct2table(data),'ttm.csv');
